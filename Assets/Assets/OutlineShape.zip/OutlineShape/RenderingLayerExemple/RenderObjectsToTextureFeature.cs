﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.Experimental.Rendering; // Pour RTHandle et RTHandles.Alloc

public class RenderObjectsToTextureFeature : ScriptableRendererFeature
{
	public RenderObjectsToTexturePass.Settings Settings = new();

	private RenderObjectsToTexturePass _renderPass;

	public override void Create()
	{
		_renderPass = new RenderObjectsToTexturePass(name, Settings);
	}

	public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
	{
		_renderPass.Setup(renderingData.cameraData.cameraTargetDescriptor);
		renderer.EnqueuePass(_renderPass);
	}
}

public class RenderObjectsToTexturePass : ScriptableRenderPass
{
	private const int DepthBufferBits = 32;

	private readonly Settings _settings;
	private RenderTextureDescriptor _descriptor;
	private FilteringSettings _filteringSettings;

	// On passe à des RTHandle
	private RTHandle _textureHandle;
	private RTHandle _tempTextureHandle;

	[Serializable]
	public class Settings
	{
		[Flags]
		public enum LightModeTags
		{
			None = 0,
			SRPDefaultUnlit = 1 << 0,
			UniversalForward = 1 << 1,
			UniversalForwardOnly = 1 << 2,
			LightweightForward = 1 << 3,
			DepthNormals = 1 << 4,
			DepthOnly = 1 << 5,
			// Regroupement “classique”
			Standard = SRPDefaultUnlit | UniversalForward | UniversalForwardOnly | LightweightForward,
		}

		public Material Material;
		public int MaterialPassIndex = -1;
		public Material BlitMaterial;
		public int BlitMaterialPassIndex = -1;
		public RenderPassEvent RenderPassEvent = RenderPassEvent.AfterRenderingOpaques;
		public ScriptableRenderPassInput RenderPassInput = ScriptableRenderPassInput.None;

		[Range(0, 5000)] public int RenderQueueLowerBound;
		[Range(0, 5000)] public int RenderQueueUpperBound = 2499;

		public RenderTextureFormat ColorFormat = RenderTextureFormat.ARGB32;
		public SortingCriteria SortingCriteria = SortingCriteria.CommonOpaque;
		public LayerMask LayerMask = -1;
		public string TextureName = "_MyTexture";

		public LightModeTags LightMode = LightModeTags.Standard;

		public GlobalKeyword[] GlobalShaderKeywords;

		[Serializable]
		public struct GlobalKeyword
		{
			public enum Mode
			{
				None,
				Enable,
				Disable,
			}

			public string Name;
			public bool Disabled;

			public Mode BeforeRenderMode;
			public Mode AfterRenderMode;
		}

		public RenderQueueRange RenderQueueRange => new(RenderQueueLowerBound, RenderQueueUpperBound);

		public List<ShaderTagId> LightModeShaderTags
		{
			get
			{
				var tags = new List<ShaderTagId>();
				if (LightMode.HasFlag(LightModeTags.SRPDefaultUnlit))
					tags.Add(new ShaderTagId("SRPDefaultUnlit"));
				if (LightMode.HasFlag(LightModeTags.UniversalForward))
					tags.Add(new ShaderTagId("UniversalForward"));
				if (LightMode.HasFlag(LightModeTags.UniversalForwardOnly))
					tags.Add(new ShaderTagId("UniversalForwardOnly"));
				if (LightMode.HasFlag(LightModeTags.LightweightForward))
					tags.Add(new ShaderTagId("LightweightForward"));
				if (LightMode.HasFlag(LightModeTags.DepthNormals))
					tags.Add(new ShaderTagId("DepthNormals"));
				if (LightMode.HasFlag(LightModeTags.DepthOnly))
					tags.Add(new ShaderTagId("DepthOnly"));
				return tags;
			}
		}
	}

	public RenderObjectsToTexturePass(string profilingName, Settings settings)
	{
		_settings = settings;
		renderPassEvent = settings.RenderPassEvent;
		profilingSampler = new ProfilingSampler(profilingName);

		// Filtrage des objets à dessiner 
		_filteringSettings = new FilteringSettings(settings.RenderQueueRange, settings.LayerMask.value);
	}

	public void Setup(RenderTextureDescriptor baseDescriptor)
	{
		// Ajuster le descripteur pour notre texture hors-écran
		baseDescriptor.colorFormat = _settings.ColorFormat;
		baseDescriptor.depthBufferBits = DepthBufferBits;
		// Souvent, on ne veut pas de MSAA dans un rendu off-screen
		baseDescriptor.msaaSamples = 1;

		_descriptor = baseDescriptor;

		// Indique quels inputs (color, depth, normal, etc.) on souhaite
		// (optionnel selon le besoin)
		ConfigureInput(_settings.RenderPassInput);
	}

	public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
	{
		// Libérer d’anciens RTHandle si on repasse
		_textureHandle?.Release();
		_tempTextureHandle?.Release();

		// Allouer notre RT principal
		_textureHandle = RTHandles.Alloc(
			_descriptor,
			FilterMode.Point,
			TextureWrapMode.Clamp,
			name: _settings.TextureName
		);

		// Allouer le RT temporaire pour le Blit
		_tempTextureHandle = RTHandles.Alloc(
			_descriptor,
			FilterMode.Point,
			TextureWrapMode.Clamp,
			name: "_TempBlitMaterialTexture"
		);

		// ⚠ Ne PAS appeler ConfigureTarget(_textureHandle) ni ConfigureClear(...) ici 
		// si vous voulez que la caméra rende normalement sur l’écran.
		// Sinon, ça va “détourner” la cible de la caméra et casser le viewport.
	}

	public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
	{
		// Préparation des settings de dessin
		var drawingSettings = CreateDrawingSettings(
			_settings.LightModeShaderTags,
			ref renderingData,
			_settings.SortingCriteria
		);
		drawingSettings.overrideMaterial = _settings.Material;
		drawingSettings.overrideMaterialPassIndex = _settings.MaterialPassIndex;

		// Création du CommandBuffer
		CommandBuffer cmd = CommandBufferPool.Get("RenderObjectsToTexture");
		using (new ProfilingScope(cmd, profilingSampler))
		{
			// 1) Activer/désactiver les keywords avant le rendu
			UpdateKeywordsBeforeRender(cmd);

			// Envoyer tout de suite ce qu’on a
			context.ExecuteCommandBuffer(cmd);
			cmd.Clear();

			// 2) Définir la cible de rendu comme étant notre texture RTHandle
			//    et effacer (clear) si besoin
			cmd.SetRenderTarget(_textureHandle,
								RenderBufferLoadAction.DontCare, RenderBufferStoreAction.Store,
								_textureHandle,
								RenderBufferLoadAction.DontCare, RenderBufferStoreAction.Store);
			cmd.ClearRenderTarget(true, true, Color.clear);

			context.ExecuteCommandBuffer(cmd);
			cmd.Clear();

			// 3) Dessiner les objets filtrés dans _textureHandle
			context.DrawRenderers(renderingData.cullResults, ref drawingSettings, ref _filteringSettings);

			// 4) (Optionnel) Blit dans _tempTextureHandle avec un Material
			if (_settings.BlitMaterial != null)
			{
				Blit(cmd, _textureHandle, _tempTextureHandle, _settings.BlitMaterial, _settings.BlitMaterialPassIndex);
				// Re‐blit dans _textureHandle si besoin
				Blit(cmd, _tempTextureHandle, _textureHandle);
			}

			// 5) Rendre la texture accessible globalement sous le nom _settings.TextureName
			cmd.SetGlobalTexture(_settings.TextureName, _textureHandle);

			// (Optionnel) Si vous voulez aussi la voir à l’écran, vous pouvez faire :
			//    Blit(cmd, _textureHandle, renderingData.cameraData.renderer.cameraColorTargetHandle);
			// avant de quitter la passe.

			// 6) Activer/désactiver les keywords après le rendu
			UpdateKeywordsAfterRender(cmd);
		}

		// Exécuter la fin du command buffer
		context.ExecuteCommandBuffer(cmd);
		CommandBufferPool.Release(cmd);
	}

	public override void OnCameraCleanup(CommandBuffer cmd)
	{
		if (cmd == null)
			throw new ArgumentNullException(nameof(cmd));

		// Libérer nos RTHandles en fin de camera
		_textureHandle?.Release();
		_tempTextureHandle?.Release();
	}

	private void UpdateKeywordsBeforeRender(CommandBuffer cmd)
	{
		if (_settings.GlobalShaderKeywords == null) return;
		foreach (var keyword in _settings.GlobalShaderKeywords)
		{
			if (keyword.Disabled)
				continue;
			switch (keyword.BeforeRenderMode)
			{
				case Settings.GlobalKeyword.Mode.None:
					break;
				case Settings.GlobalKeyword.Mode.Enable:
					cmd.EnableShaderKeyword(keyword.Name);
					break;
				case Settings.GlobalKeyword.Mode.Disable:
					cmd.DisableShaderKeyword(keyword.Name);
					break;
			}
		}
	}

	private void UpdateKeywordsAfterRender(CommandBuffer cmd)
	{
		if (_settings.GlobalShaderKeywords == null) return;
		foreach (var keyword in _settings.GlobalShaderKeywords)
		{
			if (keyword.Disabled)
				continue;
			switch (keyword.AfterRenderMode)
			{
				case Settings.GlobalKeyword.Mode.None:
					break;
				case Settings.GlobalKeyword.Mode.Enable:
					cmd.EnableShaderKeyword(keyword.Name);
					break;
				case Settings.GlobalKeyword.Mode.Disable:
					cmd.DisableShaderKeyword(keyword.Name);
					break;
			}
		}
	}
}
